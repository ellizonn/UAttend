public class utente
{
    public int matricola;
    public String tipo_utente;
    public int anno;
    public String nome;
    public String cognome;
    public indirizzo residenza;
}
