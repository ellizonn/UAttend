public class indirizzo
{
    public String via;
    public int numero;
    public String localita;
    public int CAP;
}
