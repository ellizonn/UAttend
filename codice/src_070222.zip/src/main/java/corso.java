public class corso
{
    public String nome;
    public int anno;
    public String cognome_docente;

}
