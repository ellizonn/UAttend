import java.time.LocalDate;

public class avviso
{
    public String testo;
    public LocalDate emissione;
    public LocalDate scadenza;
}
