public class account
{
    public int matricola;
    public String password;
    public boolean attivo;
}
