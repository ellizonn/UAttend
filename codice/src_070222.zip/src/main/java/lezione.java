import java.time.LocalDate;
import java.time.LocalTime;

public class lezione
{
    public String nome_corso;
    public String cognome_docente;
    public int anno;
    public int numero_aula;
    public int posti_disponibili;
    public LocalDate giorno;
    public LocalTime ora_inizio;
    public LocalTime ora_fine;
}
