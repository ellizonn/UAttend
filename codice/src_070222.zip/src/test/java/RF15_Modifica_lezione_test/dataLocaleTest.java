import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Test;

public class dataLocaleTest {
	/*
	@Test
	public void testComparaData() {
		dataLocale DoTest = new dataLocale();
		LocalDate test = LocalDate.of(2075, 12, 24);
		assertTrue(DoTest.comparaData(test) == 1);
	}
	*/

}
